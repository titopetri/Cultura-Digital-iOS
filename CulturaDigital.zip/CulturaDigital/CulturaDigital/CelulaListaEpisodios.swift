//
//  CelulaListaEpisodios.swift
//  Lista de Programas
//
//  Created by Tito Petri on 04/08/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import UIKit

class CelulaListaEpisodios: UITableViewCell {
    
    var textoTitulo:UITextView = UITextView()
    var textoDescricao:UITextView = UITextView()
    var dataPrograma:UILabel = UILabel()
    var imagem:UIImageView = UIImageView()
    var youTubeId:String = ""
    var meuIndicador:UIActivityIndicatorView = UIActivityIndicatorView()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        
        imagem.frame = CGRect(x: margemPadrao/2, y: margemPadrao/2, width: larguraTela - margemPadrao, height: alturaImagensYouTube)
        textoTitulo.frame = CGRect(x: margemPadrao/2, y: imagem.frame.maxY, width: larguraTela-margemPadrao, height: 50)
        dataPrograma.frame = CGRect(x: margemPadrao/2, y: textoTitulo.frame.maxY, width: larguraTela-margemPadrao, height: 20)
        textoDescricao.frame = CGRect(x: margemPadrao/2, y: dataPrograma.frame.maxY, width: larguraTela-margemPadrao, height: 70)
        
        textoTitulo.backgroundColor = UIColor.black
        textoTitulo.textColor = UIColor.white
        textoDescricao.backgroundColor = corChumbo 
        textoDescricao.textColor = UIColor.white
        dataPrograma.textColor = corVerde
        dataPrograma.textAlignment = .right
        
        meuIndicador.frame = imagem.frame
        
        textoTitulo.font = UIFont(name: "Roboto-Bold", size: 17)
        textoDescricao.font = UIFont(name: "Roboto-Regular", size: 13)
        dataPrograma.font = UIFont(name: "Roboto-Bold", size: 15)
        
        textoTitulo.textColor = UIColor.white
        textoDescricao.textColor = UIColor.white
        
        meuIndicador.startAnimating()
        meuIndicador.hidesWhenStopped = true
        
        imagem.contentMode = .scaleToFill
        imagem.image = UIImage(named: "icone")
        
        textoTitulo.isUserInteractionEnabled = false
        textoDescricao.isUserInteractionEnabled = false
        
        self.contentView.backgroundColor = UIColor.black
        self.contentView.addSubview(meuIndicador)
        self.contentView.addSubview(imagem)
        self.contentView.addSubview(textoTitulo)
        self.contentView.addSubview(textoDescricao)
        self.contentView.addSubview(dataPrograma)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let meuNSUrl:URL = URL(string: "http://img.youtube.com/vi/\(youTubeId)/0.jpg")!
        let networkService = NetworkService(url: meuNSUrl)
        networkService.downloadImage { (imageData) in
            let image = UIImage(data: imageData)
            DispatchQueue.main.async(execute: {
                self.meuIndicador.stopAnimating()
                self.imagem.image = image
            })
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
}
 
