//
//  MinhaCelulaTableViewCell.swift
//  ListaEpisodios
//
//  Created by Tito Petri on 19/07/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import UIKit


class CelulaListaProgramas: UITableViewCell {
    
    var textoTitulo:UILabel = UILabel()
    var textoDescricao:UITextView = UITextView()
    var textoHorarioDeExibicao:UITextView = UITextView()
    var imagem:UIImageView = UIImageView()
    var youTubeId:String = ""
    var meuIndicador:UIActivityIndicatorView = UIActivityIndicatorView()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        imagem.frame = CGRect(x: margemPadrao/2, y: margemPadrao/2, width: larguraTela - margemPadrao, height: alturaImagensProgramas)
        textoDescricao.frame = CGRect(x: margemPadrao/2, y: imagem.frame.maxY , width: larguraTela - margemPadrao  , height: 60 )
        textoHorarioDeExibicao.frame = CGRect(x: margemPadrao/2, y:  textoDescricao.frame.maxY, width: larguraTela - margemPadrao , height: 40 )
        
        textoHorarioDeExibicao.text = "Exibicao"
        textoDescricao.text = "Descricao"
        
        textoDescricao.isUserInteractionEnabled = false
        textoHorarioDeExibicao.isUserInteractionEnabled = false
        
        textoDescricao.backgroundColor = UIColor.clear
        textoHorarioDeExibicao.backgroundColor = UIColor.clear
        meuIndicador.frame = imagem.frame
        
        textoDescricao.font = UIFont(name: "Roboto-Regular", size: 13)
        textoHorarioDeExibicao.font = UIFont(name: "Roboto-Bold", size: 15)
        textoHorarioDeExibicao.textAlignment = .right
        
        textoDescricao.textColor = UIColor.white
        textoHorarioDeExibicao.textColor = corVerde
        textoDescricao.isUserInteractionEnabled = false
        
        meuIndicador.startAnimating()
        meuIndicador.hidesWhenStopped = true
        
        imagem.contentMode = .scaleToFill
        imagem.image = UIImage(named: "icone")
        
        self.contentView.backgroundColor = UIColor.black
        self.contentView.addSubview(meuIndicador)
        self.contentView.addSubview(imagem)
        self.contentView.addSubview(textoHorarioDeExibicao)
        self.contentView.addSubview(textoDescricao)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let meuNSUrl:URL = URL(string: youTubeId)!
        let networkService = NetworkService(url: meuNSUrl)
        networkService.downloadImage { (imageData) in
            let image = UIImage(data: imageData)
            DispatchQueue.main.async(execute: {
                self.meuIndicador.stopAnimating()
                self.imagem.image = image
            })
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
}
 
