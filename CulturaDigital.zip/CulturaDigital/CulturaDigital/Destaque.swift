//
//  Destaque.swift
//  AppTVCultura
//
//  Created by Tito Petri on 05/08/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import Foundation
 
class Destaque {

    var titulo:String
    var descricao:String
    var youtubeID:String
    var nomePrograma:String
    var dataDestaque:String
    
    init(titulo:String, descricao:String, youtubeID:String, nomePrograma:String, dataDestaque:String){
    
        self.titulo = titulo
        self.descricao = descricao
        self.youtubeID = youtubeID
        self.nomePrograma = nomePrograma
        self.dataDestaque = dataDestaque
    }

}