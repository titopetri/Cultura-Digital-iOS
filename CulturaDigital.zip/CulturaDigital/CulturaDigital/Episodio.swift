//
//  Episodio.swift
//  ListaEpisodios
//
//  Created by Tito Petri on 20/07/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import Foundation

class Episodio {
    
    var titulo:String
    var descricao:String
    var youtubeID:String
    var dataEpisodio:String
    
    init(titulo:String, descricao:String, youtubeID:String, dataEpisodio:String){
        
        self.titulo = titulo
        self.descricao = descricao
        self.youtubeID = youtubeID
        self.dataEpisodio = dataEpisodio
    }
    
}