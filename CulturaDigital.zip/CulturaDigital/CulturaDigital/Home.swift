//
//  ViewController.swift
//  CulturaDigital
//
//  Created by Tito Petri on 09/09/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import UIKit

var larguraTela:CGFloat = UIScreen.main.bounds.width
var alturaTela:CGFloat = UIScreen.main.bounds.height
var alturaNavbar:CGFloat = CGFloat()
let margemPadrao:CGFloat = 10
let alturaStatusBar = UIApplication.shared.statusBarFrame.size.height
let corVerde:UIColor = UIColor(red:92/255.0, green:187/255.0, blue:72/255.0, alpha: 1.0)
let corChumbo:UIColor = UIColor(red: 0.05, green: 0.05, blue: 0.05, alpha: 1)
let corAzul:UIColor = UIColor(red: 0.25, green: 0.25, blue: 0.80, alpha: 1)
let alturaImagensProgramas = (larguraTela - margemPadrao)/1.84
let alturaImagensYouTube = (larguraTela - margemPadrao)/1.33
let listaImagensRadio:[String] = ["radio_cultura_fm_color","radio_cultura_brasil_color"]
var radioSelecionada:String = "CulturaFM" // "CulturaBrasil"
var urlRadio:String = ""


class Home: UIViewController, MenuLateralDelegate {
    
    var blurView:UIVisualEffectView = UIVisualEffectView()
    var meuMenulateral:MenuLateral = MenuLateral()
    let botaoMenu = UIButton()
    var estadoMenuLateral:Bool = true
    
    var meuScrollViewDestaques:UIScrollView = UIScrollView()
    var meuScrollViewPrincipal:UIScrollView = UIScrollView()
    var meuPageControl:UIPageControl = UIPageControl()
    var meuTextoTitulo:UILabel = UILabel()
    var meuTextoDescricao:UILabel = UILabel()
    var meuTimerDestaque = Timer()
    var minhaTarja:UIView = UIView()
    var botaoGo:UIButton = UIButton()
    var botaoBack:UIButton = UIButton()
    
    var listaDestaques:[Destaque] = []
    var listaProgramas:[Programa] = []
    var listaAcervo:[Programa] = []
    var ponteiroAlturaY:CGFloat = 0
    
    var tagClicada:Int = 999
    
    var selecionouAcervo:Bool = false
    var clicouBusca:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        verificarConexao()
    }
    
    func verificarConexao(){
        
        blurView = UIVisualEffectView(effect: UIBlurEffect(style: UIBlurEffectStyle.dark))
        blurView.frame = CGRect(x: 0, y: 0, width: larguraTela, height: alturaTela)
        
        let meuIndicadorConect:UIActivityIndicatorView = UIActivityIndicatorView(frame: blurView.frame)
        let labelConect:UILabel = UILabel(frame: CGRect(x: 0, y: 30, width: larguraTela, height: alturaTela))
        
        meuIndicadorConect.startAnimating()
        labelConect.text = "Verificando conexão..."
        labelConect.textColor = UIColor.white
        labelConect.font = UIFont(name: "Roboto-Bold", size: 17)
        labelConect.alpha = 0.5
        labelConect.textAlignment = .center
        
        blurView.addSubview(meuIndicadorConect)
        blurView.addSubview(labelConect)
        self.view.addSubview(blurView)
        testarConexaoInternet()
    }
    
    func testarConexaoInternet(){
        if Reachability.isConnectedToNetwork() == true {
            print("Conectado!!!")
            blurView.removeFromSuperview()
            self.view.backgroundColor = UIColor.black
            configuraNavigationBar()
            
        } else {
            let alertController = UIAlertController(title: "Sem Conexão com a Internet", message: "Certifique-se que seu dispositvo esteja conectado", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Continuar", style: UIAlertActionStyle.default,handler: nil))
            self.navigationController!.present(alertController, animated: true, completion: nil)
        }
    }
    
    func configuraNavigationBar(){
        
        let meuNavigationBar = self.navigationController?.navigationBar
        let meuLogoCulturaDigital = UIImageView(frame: CGRect(x: 0, y: 0, width: 100, height: 24))
        let minhaImagemLogoCulturaDigital = UIImage(named: "logotipoCulturaDigitalTopo")
        let seletorMenu: Selector = #selector(Home.clicaOpcaoMenu)
        let seletorBusca: Selector = #selector(Home.clicaOpcaoBusca)
        let imageViewLogo = UIImageView(frame: CGRect(x: 0, y: 0, width: 100, height: 24))
        let imagemLogo = UIImage(named: "logotipoCulturaDigitalTopo")
        
        let botaoBusca = UIButton()
        
        let botaoBarraMenu = UIBarButtonItem()
        let botaoBarraBusca = UIBarButtonItem()
        
        meuNavigationBar?.barStyle = UIBarStyle.black
        meuNavigationBar?.tintColor = UIColor.green
        
        meuLogoCulturaDigital.image = minhaImagemLogoCulturaDigital
        meuLogoCulturaDigital.contentMode = .scaleAspectFit
        navigationItem.titleView = meuLogoCulturaDigital
        
        imageViewLogo.contentMode = .scaleAspectFit
        imageViewLogo.image = imagemLogo
        navigationItem.titleView = imageViewLogo
        
        botaoMenu.setImage(UIImage(named: "iconeMenu"), for: UIControlState())
        botaoMenu.frame = CGRect(x: 0, y: 0, width: 23,height: 15)
        botaoMenu.addTarget(self, action: seletorMenu, for: .touchUpInside)
        
        botaoBusca.setImage(UIImage(named: "iconeBusca"), for: UIControlState())
        botaoBusca.frame = CGRect(x: 0, y: 0, width: 17,height: 16)
        botaoBusca.addTarget(self, action: seletorBusca, for: .touchUpInside)
        
        botaoBarraMenu.customView = botaoMenu
        botaoBarraBusca.customView = botaoBusca
        
        self.navigationItem.rightBarButtonItem = botaoBarraBusca
        self.navigationItem.leftBarButtonItem = botaoBarraMenu
        
        larguraTela = UIScreen.main.bounds.width
        alturaTela = UIScreen.main.bounds.height
        alturaNavbar = meuNavigationBar!.frame.size.height
        
        configuraScrollViewPrincipal()
        
    }
    
    
    func configuraScrollViewPrincipal(){
        meuScrollViewPrincipal  = UIScrollView(frame: CGRect(x: 0, y: margemPadrao/2, width: larguraTela,height: alturaTela-margemPadrao))
        meuScrollViewPrincipal.backgroundColor = UIColor.black
        meuScrollViewPrincipal.showsVerticalScrollIndicator = false
        meuScrollViewPrincipal.showsHorizontalScrollIndicator = false
        
        meuScrollViewDestaques  = UIScrollView(frame: CGRect(x: 0, y: 0, width: larguraTela,height: alturaTela/3))
        meuScrollViewDestaques.backgroundColor = UIColor.darkGray
        meuScrollViewDestaques.showsVerticalScrollIndicator = false
        meuScrollViewDestaques.showsHorizontalScrollIndicator = false
        meuScrollViewDestaques.isScrollEnabled = false
        
        meuPageControl  = UIPageControl(frame: CGRect(x: 0, y: meuScrollViewDestaques.frame.size.height, width: larguraTela, height: 20))
        meuPageControl.pageIndicatorTintColor = UIColor.white
        meuPageControl.currentPageIndicatorTintColor = UIColor(red:92/255.0, green:187/255.0, blue:72/255.0, alpha: 1.0)
        
        minhaTarja = UIView(frame: CGRect(x: 0, y: meuScrollViewDestaques.frame.size.height - 50, width: larguraTela, height: 40))
        minhaTarja.backgroundColor = UIColor.darkGray
        minhaTarja.alpha = 0.85
        
        meuTextoTitulo = UILabel(frame: CGRect(x: 10, y: meuScrollViewDestaques.frame.size.height - 45, width: larguraTela, height: 20))
        meuTextoTitulo.text = "Título Programa A"
        meuTextoTitulo.font = UIFont(name: "Roboto-Bold", size: 12)
        meuTextoTitulo.textColor = UIColor.white
        
        meuTextoDescricao = UILabel(frame: CGRect(x: 10, y: meuScrollViewDestaques.frame.size.height - 35, width: larguraTela, height: 25))
        meuTextoDescricao.text = "descrição programa xyz..."
        meuTextoDescricao.font = UIFont(name: "Roboto-Regular", size: 12)
        meuTextoDescricao.textColor = UIColor.white
        
        botaoGo = UIButton(frame: CGRect(x: larguraTela - 30 - 10, y: meuScrollViewDestaques.frame.size.height/2 - 15, width: 30, height: 30))
        botaoGo.setImage(UIImage(named: "iconeGo"), for: UIControlState())
        botaoGo.alpha = 0.75
        botaoGo.addTarget(self, action: #selector(clicaSetaDestaqueGo), for:.touchUpInside)
        
        botaoBack = UIButton(frame: CGRect(x: 10, y: meuScrollViewDestaques.frame.size.height/2 - 15, width: 30, height: 30))
        botaoBack.setImage(UIImage(named: "iconeBack"), for: UIControlState())
        botaoBack.alpha = 0.75
        botaoBack.addTarget(self, action: #selector(clicaSetaDestaqueBack),for:.touchUpInside)
        
        meuScrollViewDestaques.contentSize = CGSize(width: larguraTela*CGFloat(meuPageControl.numberOfPages+1), height: 0)
        
        self.view.addSubview(meuScrollViewPrincipal)
        meuScrollViewPrincipal.addSubview(meuScrollViewDestaques)
        meuScrollViewPrincipal.addSubview(meuPageControl)
        meuScrollViewPrincipal.addSubview(minhaTarja)
        meuScrollViewPrincipal.addSubview(meuTextoTitulo)
        meuScrollViewPrincipal.addSubview(meuTextoDescricao)
        meuScrollViewPrincipal.addSubview(botaoGo)
        meuScrollViewPrincipal.addSubview(botaoBack)
        
        let gestoSwipeDireita:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(Home.AcaoSwipe(_:)))
        gestoSwipeDireita.direction = UISwipeGestureRecognizerDirection.right
        meuScrollViewDestaques.addGestureRecognizer(gestoSwipeDireita)
        
        let gestoSwipeEsquerda:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(Home.AcaoSwipe(_:)))
        gestoSwipeEsquerda.direction = UISwipeGestureRecognizerDirection.left
        meuScrollViewDestaques.addGestureRecognizer(gestoSwipeEsquerda)
        
        configuraMenuLateral()
        buscaDestaques()
    }
    
    func configuraMenuLateral(){
        meuMenulateral = MenuLateral(sourceView: self.view, menuItems: ["Meu Perfil", "Notificações", "Enquetes",  "Envio de Mídia"],larguraBarra: UIScreen.main.bounds.width/2)
        meuMenulateral.delegate = self
    }
    
    
    
    
    
    /*
     
     func buscaDestaquesOLD(){
     
     let apiUrl = "http://api.tvcultura.com.br/appdestaque/"
     
     let url = URL(string: apiUrl)
     let session = URLSession.shared
     
     listaDestaques = []
     
     let task = session.dataTask(with: url!, completionHandler: {data, response, error -> Void in
     if (error != nil){
     print(error!.localizedDescription)
     }else{
     let nsdata:Data = NSData(data: data!) as Data
     do{
     
     let jsonCompleto = try JSONSerialization.jsonObject(with: nsdata, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String:Any]
     if let arrayComJason = jsonCompleto["result"] as? NSArray{
     arrayComJason.enumerateObjects({ (objeto, index, stop) in
     
     
     
     
     let objetoAppDestaque = objeto["appdestaque"] as! NSDictionary
     let objetoInfo = objeto["info"] as! NSDictionary
     
     let novoDestaque:Destaque = Destaque(titulo: (objetoInfo["title"]! as! String), descricao: (objetoAppDestaque["chapeu"]! as! String), youtubeID: (objetoAppDestaque["link"]! as! String), nomePrograma: (objetoAppDestaque["chapeu"]! as! String), dataDestaque: (objetoAppDestaque["date"]! as! String))
     
     self.listaDestaques.append(novoDestaque)
     })
     
     DispatchQueue.main.async(execute: {
     self.inicializaCarrosselDestaques()
     self.meuTimerDestaque = Timer.scheduledTimer(timeInterval: 3.75, target: self, selector: #selector(self.clicaSetaDestaqueGo), userInfo: nil, repeats: false)
     })
     }
     }
     catch {}
     }
     })
     task.resume()
     }
     
     */
    
    
    
    func buscaDestaques()
    {
        listaDestaques = []
        
        let url = NSURL(string: "http://api.tvcultura.com.br/appdestaque/")
        let request = NSMutableURLRequest(url: url! as URL)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data,response,error in
            guard error == nil && data != nil else
            {
                print("Error:",error)
                return
            }
            
            let httpStatus = response as? HTTPURLResponse
            
            if httpStatus!.statusCode == 200
            {
                if data?.count != 0
                {
                    let responseString = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! NSDictionary
                    
                    
                    if let resultado = responseString["result"] as? [AnyObject] // posts started with array
                    {
                        for post in resultado
                        {
                            let appDestaque = post["appdestaque"] as! NSDictionary
                            let titulo = appDestaque["title"] as! String
                            let chapeu = appDestaque["chapeu"] as! String
                            let link = appDestaque["link"] as! String
                            let dataexib = appDestaque["date"] as! String
                            
                            let novoDestaque:Destaque = Destaque(titulo: titulo, descricao: chapeu, youtubeID: link, nomePrograma: titulo, dataDestaque: dataexib)
                            
                            
                            self.listaDestaques.append(novoDestaque)
                            
                            
                        }
                        DispatchQueue.main.sync
                            {
                                self.inicializaCarrosselDestaques()
                                self.meuTimerDestaque = Timer.scheduledTimer(timeInterval: 3.75, target: self, selector: #selector(self.clicaSetaDestaqueGo), userInfo: nil, repeats: false)
                        }
                    }
                    else{ print("I could not find post array")}
                }
                else{ print("No data got from url!")}
            }
            else{ print("error httpstatus code is :",httpStatus!.statusCode)}
        }
        task.resume()
    }
    
    
    
    
    
    
    func inicializaCarrosselDestaques(){
        
        meuPageControl.numberOfPages = listaDestaques.count
        
        for i in 0...meuPageControl.numberOfPages-1{
            let imgDestaque:UIImageView = UIImageView(frame:CGRect(x: larguraTela*CGFloat(i), y: 0, width: larguraTela, height: meuScrollViewDestaques.frame.size.height))
            let indicador:UIActivityIndicatorView = UIActivityIndicatorView(frame:imgDestaque.frame)
            imgDestaque.image = UIImage(named:"iconeCultura")
            imgDestaque.contentMode = .scaleAspectFill
            imgDestaque.tag = 300 + i
            indicador.startAnimating()
            indicador.hidesWhenStopped = true
            
            meuScrollViewDestaques.addSubview(imgDestaque)
            meuScrollViewDestaques.addSubview(indicador)
            
            imgDestaque.isUserInteractionEnabled = true
            let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(Home.clicaLogoPrograma(_:)))
            imgDestaque.addGestureRecognizer(tapRecognizer)
            
            let meuNSUrl:URL = URL(string: "http://img.youtube.com/vi/\(listaDestaques[i].youtubeID)/0.jpg")!
            let networkService = NetworkService(url: meuNSUrl)
            networkService.downloadImage { (imageData) in
                let image = UIImage(data: imageData)
                DispatchQueue.main.async(execute: {
                    indicador.stopAnimating()
                    imgDestaque.image = image
                })
            }
        }
        
        buscaPorProgramas(0, numeroDeProgramas: 10)
        
    }
    
    func clicaSetaDestaqueGo(){
        if meuPageControl.currentPage<meuPageControl.numberOfPages-1 {
            meuPageControl.currentPage = meuPageControl.currentPage+1
        }else{
            meuPageControl.currentPage = 0
        }
        atualizaScrollViewDestaques()
    }
    
    func clicaSetaDestaqueBack(){
        if meuPageControl.currentPage>0 {
            meuPageControl.currentPage = meuPageControl.currentPage-1
        }else{
            meuPageControl.currentPage = meuPageControl.numberOfPages
        }
        atualizaScrollViewDestaques()
    }
    
    func atualizaScrollViewDestaques(){
        
        self.meuTimerDestaque.invalidate()
        meuTimerDestaque = Timer.scheduledTimer(timeInterval: 7.35, target: self, selector: #selector(clicaSetaDestaqueGo), userInfo: nil, repeats: false)
        
        meuTextoTitulo.text = listaDestaques[meuPageControl.currentPage].titulo
        meuTextoDescricao.text = listaDestaques[meuPageControl.currentPage].descricao
        
        let offset =  UIScreen.main.bounds.width * CGFloat(meuPageControl.currentPage)
        self.meuScrollViewDestaques.setContentOffset(CGPoint(x:  offset, y: 0), animated: true)
    }
    
    
    func AcaoSwipe(_ gesto:UIGestureRecognizer){
        let  swipeGesto = gesto as? UISwipeGestureRecognizer
        if(swipeGesto!.direction == UISwipeGestureRecognizerDirection.right)
        {
            clicaSetaDestaqueBack()
        }
        if(swipeGesto!.direction == UISwipeGestureRecognizerDirection.left)
        {
            clicaSetaDestaqueGo()
        }
    }
    
    func clicaOpcaoBusca() {
        clicouBusca = true
        self.performSegue(withIdentifier: "HomeParaEpisodios", sender: nil)
    }
    
    func clicaOpcaoMenu() {
        meuMenulateral.showSideBar(estadoMenuLateral)
        estadoMenuLateral = !estadoMenuLateral
        
        if !estadoMenuLateral {
            botaoMenu.alpha = 0.5
        }else{
            botaoMenu.alpha = 1
        }
    }
    
    
    func sideBarDidSelectButtonAtIndex(_ index: Int) {
        if index == 0{
        }else if index == 1{ print("Opcao 1 Selecionada")
        }else if index == 2{ print("Opcao 2 Selecionada")
        }else if index == 3{ print("Opcao 3 Selecionada")
        }else if index == 4{ print("Opcao 4 Selecionada")
        }
    }
    
    func inicializaMenuProgramas(_ numeroDeProgramas:Int, numeroDeColunas:CGFloat ){
        
        ponteiroAlturaY = meuScrollViewDestaques.frame.size.height + meuPageControl.frame.size.height+10
        
        let larguraLogoPgm = UIScreen.main.bounds.width / 2 - margemPadrao*1.5
        let alturaLogoPgm:CGFloat = larguraLogoPgm/1.84
        
        let meuTitulo:UILabel = UILabel(frame: CGRect(x: margemPadrao, y: ponteiroAlturaY, width: larguraTela, height: 20))
        
        ponteiroAlturaY += meuTitulo.frame.size.height
        
        let tarja:UIView = UIView(frame: CGRect(x: margemPadrao, y: ponteiroAlturaY, width: larguraTela - 2*margemPadrao, height: 5))
        meuTitulo.text = "Programas"
        meuTitulo.font = UIFont(name:"Roboto-Bold", size: 17)
        meuTitulo.textColor = UIColor.white
        tarja.backgroundColor = corVerde
        
        ponteiroAlturaY += tarja.frame.size.height + margemPadrao
        
        meuScrollViewPrincipal.addSubview(meuTitulo)
        meuScrollViewPrincipal.addSubview(tarja)
        
        for i in 0...numeroDeProgramas-1{
            
            let meuLogoPrograma:UIImageView = UIImageView(frame: CGRect(x: 10, y: ponteiroAlturaY , width: larguraLogoPgm, height: alturaLogoPgm))
            meuLogoPrograma.frame.origin.x = (CGFloat(i).truncatingRemainder(dividingBy: numeroDeColunas)) * larguraLogoPgm + (margemPadrao * (CGFloat(i).truncatingRemainder(dividingBy: numeroDeColunas))) + margemPadrao
            meuLogoPrograma.frame.origin.y = ponteiroAlturaY + floor(CGFloat(i)/2)*(alturaLogoPgm + margemPadrao)
            meuLogoPrograma.image = UIImage(named:"iconeCultura")
            meuLogoPrograma.contentMode = .scaleToFill
            meuLogoPrograma.tag = i
            meuLogoPrograma.isUserInteractionEnabled = true
            
            let indicador:UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: meuLogoPrograma.frame.width, height: meuLogoPrograma.frame.height))
            indicador.startAnimating()
            indicador.hidesWhenStopped = true
            
            
            meuLogoPrograma.isUserInteractionEnabled = true
            //now you need a tap gesture recognizer
            //note that target and action point to what happens when the action is recognized.
            let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(Home.clicaLogoPrograma(_:)))
            //Add the recognizer to your view.
            meuLogoPrograma.addGestureRecognizer(tapRecognizer)
            
            
            //            let tapRec = UITapGestureRecognizer()
            //            tapRec.addTarget(self, action: #selector(Home.clicaLogoPrograma))
            //            meuLogoPrograma.addGestureRecognizer(tapRec)
            
            meuScrollViewPrincipal.addSubview(meuLogoPrograma)
            meuLogoPrograma.addSubview(indicador)
            
            let meuNSUrl:URL = URL(string: listaProgramas[i].youtubeID)!
            let networkService = NetworkService(url: meuNSUrl)
            networkService.downloadImage { (imageData) in
                let image = UIImage(data: imageData)
                DispatchQueue.main.async(execute: {
                    indicador.stopAnimating()
                    meuLogoPrograma.image = image
                })
            }
            
            
            if i==numeroDeProgramas-1 {
                ponteiroAlturaY = meuLogoPrograma.frame.maxY + 10
                
                let botaoMaisProgramas = UIButton(frame: CGRect(x: margemPadrao, y: ponteiroAlturaY, width: larguraTela-2*margemPadrao , height: 40))
                ponteiroAlturaY+=botaoMaisProgramas.frame.size.height
                
                botaoMaisProgramas.addTarget(self, action: #selector(clicaMaisProgramas), for: .touchUpInside)
                botaoMaisProgramas.tag = 1
                
                botaoMaisProgramas.titleLabel?.font = UIFont(name: "Roboto-Bold", size: 12)
                
                let borderAlpha : CGFloat = 0.7
                let cornerRadius : CGFloat = 5.0
                
                botaoMaisProgramas.setTitle("+ MAIS PROGRAMAS", for: UIControlState())
                botaoMaisProgramas.setTitleColor(UIColor.white, for: UIControlState())
                botaoMaisProgramas.backgroundColor = UIColor.clear
                botaoMaisProgramas.layer.borderWidth = 1.0
                botaoMaisProgramas.layer.borderColor = UIColor(white: 1.0, alpha: borderAlpha).cgColor
                botaoMaisProgramas.layer.cornerRadius = cornerRadius
                
                meuScrollViewPrincipal.addSubview(botaoMaisProgramas)
                ponteiroAlturaY += 10
                meuScrollViewPrincipal.contentSize = CGSize(width: larguraTela, height: ponteiroAlturaY+20)
                
            }
        }
                inicializaMenuRadios(2, numeroDeColunas:2)
    }
    
    
    func inicializaMenuRadios(_ numeroDeIcones:Int, numeroDeColunas:CGFloat ){
        
        let larguraLogoPgm = UIScreen.main.bounds.width / 2 - margemPadrao*1.5
        let alturaLogoPgm:CGFloat = larguraLogoPgm/1.84
        
        let meuTitulo:UILabel = UILabel(frame: CGRect(x: margemPadrao, y: ponteiroAlturaY, width: larguraTela, height: 20))
        
        ponteiroAlturaY += meuTitulo.frame.size.height + 10
        
        let tarja:UIView = UIView(frame: CGRect(x: margemPadrao, y: ponteiroAlturaY, width: larguraTela - 2*margemPadrao, height: 5))
        meuTitulo.text = "Rádios"
        meuTitulo.font = UIFont(name:"Roboto-Bold", size: 17)
        meuTitulo.textColor = UIColor.white
        tarja.backgroundColor = corVerde
        
        ponteiroAlturaY += tarja.frame.size.height + margemPadrao
        
        meuScrollViewPrincipal.addSubview(meuTitulo)
        meuScrollViewPrincipal.addSubview(tarja)
        
        for i in 0...numeroDeIcones-1{
            
            let meuLogoPrograma:UIImageView = UIImageView(frame: CGRect(x: 10, y: ponteiroAlturaY , width: larguraLogoPgm, height: alturaLogoPgm))
            meuLogoPrograma.frame.origin.x = (CGFloat(i).truncatingRemainder(dividingBy: numeroDeColunas)) * larguraLogoPgm + (margemPadrao * (CGFloat(i).truncatingRemainder(dividingBy: numeroDeColunas))) + margemPadrao
            meuLogoPrograma.frame.origin.y = ponteiroAlturaY + floor(CGFloat(i)/2)*(alturaLogoPgm + margemPadrao)
            meuLogoPrograma.image = UIImage(named:listaImagensRadio[i])
            meuLogoPrograma.contentMode = .scaleToFill
            meuLogoPrograma.tag = 500+i
            meuLogoPrograma.isUserInteractionEnabled = true
            
            let tapRec = UITapGestureRecognizer()
            tapRec.addTarget(self, action: #selector(Home.clicaLogoPrograma))
            meuLogoPrograma.addGestureRecognizer(tapRec)
            
            meuScrollViewPrincipal.addSubview(meuLogoPrograma)
            
            if i==numeroDeIcones-1 {
                ponteiroAlturaY = meuLogoPrograma.frame.maxY + 20
                meuScrollViewPrincipal.contentSize = CGSize(width: larguraTela, height: ponteiroAlturaY)
            }
        }
        
        buscaPorAcervo(10, numeroDeProgramas: 6)
    }
    
    
    
    func inicializaMenuAcervos(_ numeroDeProgramas:Int, numeroDeColunas:CGFloat ){
        
        let larguraLogoPgm = UIScreen.main.bounds.width / 2 - margemPadrao*1.5
        let alturaLogoPgm:CGFloat = larguraLogoPgm/1.84
        
        let meuTitulo:UILabel = UILabel(frame: CGRect(x: margemPadrao, y: ponteiroAlturaY, width: larguraTela, height: 20))
        
        ponteiroAlturaY += meuTitulo.frame.size.height
        
        let tarja:UIView = UIView(frame: CGRect(x: margemPadrao, y: ponteiroAlturaY, width: larguraTela - 2*margemPadrao, height: 5))
        meuTitulo.text = "Acervo"
        meuTitulo.font = UIFont(name:"Roboto-Bold", size: 17)
        meuTitulo.textColor = UIColor.white
        tarja.backgroundColor = corVerde
        
        ponteiroAlturaY += tarja.frame.size.height + margemPadrao
        
        meuScrollViewPrincipal.addSubview(meuTitulo)
        meuScrollViewPrincipal.addSubview(tarja)
        
        for i in 0...numeroDeProgramas-1{
            
            let meuLogoPrograma:UIImageView = UIImageView(frame: CGRect(x: 10, y: ponteiroAlturaY , width: larguraLogoPgm, height: alturaLogoPgm))
            meuLogoPrograma.frame.origin.x = (CGFloat(i).truncatingRemainder(dividingBy: numeroDeColunas)) * larguraLogoPgm + (margemPadrao * (CGFloat(i).truncatingRemainder(dividingBy: numeroDeColunas))) + margemPadrao
            meuLogoPrograma.frame.origin.y = ponteiroAlturaY + floor(CGFloat(i)/2)*(alturaLogoPgm + margemPadrao)
            meuLogoPrograma.image = UIImage(named:"iconeCultura")
            meuLogoPrograma.contentMode = .scaleToFill
            meuLogoPrograma.tag = 900+i
            meuLogoPrograma.isUserInteractionEnabled = true
            
            let indicador:UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: meuLogoPrograma.frame.width, height: meuLogoPrograma.frame.height))
            indicador.startAnimating()
            indicador.hidesWhenStopped = true
            
            let tapRec = UITapGestureRecognizer()
            tapRec.addTarget(self, action: #selector(Home.clicaLogoPrograma))
            meuLogoPrograma.addGestureRecognizer(tapRec)
            
            meuScrollViewPrincipal.addSubview(meuLogoPrograma)
            meuLogoPrograma.addSubview(indicador)
            
            let meuNSUrl:URL = URL(string: listaAcervo[i].youtubeID)!
            let networkService = NetworkService(url: meuNSUrl)
            networkService.downloadImage { (imageData) in
                let image = UIImage(data: imageData)
                DispatchQueue.main.async(execute: {
                    indicador.stopAnimating()
                    meuLogoPrograma.image = image
                })
            }
            
            
            if i==numeroDeProgramas-1 {
                ponteiroAlturaY = meuLogoPrograma.frame.maxY + 10
                
                let botaoMaisProgramas = UIButton(frame: CGRect(x: margemPadrao, y: ponteiroAlturaY, width: larguraTela-2*margemPadrao , height: 40))
                ponteiroAlturaY+=botaoMaisProgramas.frame.size.height
                
                botaoMaisProgramas.addTarget(self, action: #selector(clicaMaisProgramas), for: .touchUpInside)
                botaoMaisProgramas.tag = 2
                
                botaoMaisProgramas.titleLabel?.font = UIFont(name: "Roboto-Bold", size: 12)
                
                let borderAlpha : CGFloat = 0.7
                let cornerRadius : CGFloat = 5.0
                
                botaoMaisProgramas.setTitle("+ MAIS ACERVO", for: UIControlState())
                botaoMaisProgramas.setTitleColor(UIColor.white, for: UIControlState())
                botaoMaisProgramas.backgroundColor = UIColor.clear
                botaoMaisProgramas.layer.borderWidth = 1.0
                botaoMaisProgramas.layer.borderColor = UIColor(white: 1.0, alpha: borderAlpha).cgColor
                botaoMaisProgramas.layer.cornerRadius = cornerRadius
                
                meuScrollViewPrincipal.addSubview(botaoMaisProgramas)
                ponteiroAlturaY += 10
                meuScrollViewPrincipal.contentSize = CGSize(width: larguraTela, height: ponteiroAlturaY+20)
            }
        }
    }
    
    
    
    
    
    
    /*
     
     func buscaPorProgramasOLD(_ inicio:Int, numeroDeProgramas:Int){
     
     let apiUrl = "http://tvcultura.com.br/json/programas/?app=true"
     let url = URL(string: apiUrl)
     let session = URLSession.shared
     
     let task = session.dataTask(with: url!, completionHandler: {data, response, error -> Void in
     if (error != nil){
     print(error!.localizedDescription)
     }else{
     let nsdata:Data = NSData(data: data!) as Data
     do{
     let jsonCompleto = try JSONSerialization.jsonObject(with: nsdata, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String:Any]
     if let arrayComJason = jsonCompleto["result"] as? NSArray{
     
     arrayComJason.enumerateObjects({ (objeto, index, stop) in
     
     let objetoInfo = objeto["info"] as! NSDictionary
     let objetoProgramas = objeto["programas"] as! NSDictionary
     let novoPrograma:Programa = Programa(nome: (objetoInfo["title"]! as! String), descricao: (objetoProgramas["description"]! as! String),slug:(objetoInfo["slug"])! as! String, youtubeID:(objetoProgramas["logoAppPath"]! as! String), data:(objetoInfo["date"]! as! String), exibicao:(objetoProgramas["exhibitionTime"]! as! String))
     
     self.listaProgramas.append(novoPrograma)
     })
     DispatchQueue.main.async(execute: {
     self.inicializaMenuProgramas(numeroDeProgramas, numeroDeColunas: 2)
     } )
     }
     }
     catch {}
     }
     })
     task.resume()
     }
     
     
     */
    
    
    
    
    
    
    
    func buscaPorProgramas(_ inicio:Int, numeroDeProgramas:Int){
        
        let apiUrl = "http://tvcultura.com.br/json/programas/?app=true"
        let url = URL(string: apiUrl)
        let request = NSMutableURLRequest(url: url! as URL)
        
        listaProgramas = []
        
        let task2 = URLSession.shared.dataTask(with: request as URLRequest) { data,response,error in
            guard error == nil && data != nil else
            {
                print("Error:",error)
                return
            }
            
            let httpStatus = response as? HTTPURLResponse
            
            if httpStatus!.statusCode == 200
            {
                if data?.count != 0
                {
                    let responseString = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! NSDictionary
                    
                    if let resultado = responseString["result"] as? [AnyObject]
                    {
                        for post in resultado
                        {
                            
                            let objetoInfo = post["info"] as! NSDictionary
                            let objetoProgramas = post["programas"] as! NSDictionary
                            
                            
                            let titulo = objetoInfo["title"] as! String
                            let slug = objetoInfo["slug"] as! String
                            let dataexib = objetoInfo["date"] as! String
                            
                            let descricao = objetoProgramas["description"] as! String
                            let logoPrograma = objetoProgramas["logoAppPath"] as! String
                            let exibicao = objetoProgramas["exhibitionTime"] as! String
                            
                            
                            let novoPrograma:Programa = Programa(nome: titulo, descricao: descricao, slug: slug, youtubeID: logoPrograma, data: dataexib, exibicao: exibicao)
                            self.listaProgramas.append(novoPrograma)
                            
                        }
                        DispatchQueue.main.sync
                            {
                                self.inicializaMenuProgramas(numeroDeProgramas, numeroDeColunas: 2)
                        }
                    }
                    else{ print("I could not find post array")}
                }
                else{ print("No data got from url!")}
            }
            else{ print("error httpstatus code is :",httpStatus!.statusCode)}
        }
        task2.resume()
    }
    
    
    
    
    
    
    
    
    
    
    /*
     
     func buscaPorAcervoOLD(_ inicio:Int, numeroDeProgramas:Int){
     
     let apiUrl = "http://tvcultura.com.br/json/programas/?app=true&start=\(inicio)&rows=\(numeroDeProgramas)"
     
     let url = URL(string: apiUrl)
     let session = URLSession.shared
     
     let task = session.dataTask(with: url!, completionHandler: {data, response, error -> Void in
     if (error != nil){
     print(error!.localizedDescription)
     }else{
     let nsdata:Data = NSData(data: data!) as Data
     do{
     let jsonCompleto = try JSONSerialization.jsonObject(with: nsdata, options: JSONSerialization.ReadingOptions.mutableContainers)
     if let arrayComJason = jsonCompleto["result"] as? NSArray{
     
     arrayComJason.enumerateObjects({ (objeto, index, stop) in
     
     let objetoInfo = objeto["info"] as! NSDictionary
     let objetoProgramas = objeto["programas"] as! NSDictionary
     let novoPrograma:Programa = Programa(nome: (objetoInfo["title"]! as! String), descricao: (objetoProgramas["description"]! as! String),slug:(objetoInfo["slug"])! as! String, youtubeID:(objetoProgramas["logoAppPath"]! as! String), data:(objetoInfo["date"]! as! String), exibicao:(objetoProgramas["exhibitionTime"]! as! String))
     
     self.listaAcervo.append(novoPrograma)
     })
     DispatchQueue.main.async(execute: {
     self.inicializaMenuAcervos(numeroDeProgramas, numeroDeColunas: 2)
     } )
     }
     }
     catch {}
     }
     })
     task.resume()
     }
     
     */
    
    
    
    
    
    
    
    func buscaPorAcervo(_ inicio:Int, numeroDeProgramas:Int){
        
        let apiUrl = "http://tvcultura.com.br/json/programas/?app=true&start=\(inicio)&rows=\(numeroDeProgramas)"
        let url = URL(string: apiUrl)
        let request = NSMutableURLRequest(url: url! as URL)
        
        listaAcervo = []
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data,response,error in
            guard error == nil && data != nil else
            {
                print("Error:",error)
                return
            }
            
            let httpStatus = response as? HTTPURLResponse
            
            if httpStatus!.statusCode == 200
            {
                if data?.count != 0
                {
                    let responseString = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! NSDictionary
                    
                    //                    let temProximo = responseString["hasNext"] as! Bool
                    //                    let proximoInicio = responseString["nextStart"] as! Int
                    
                    if let resultado = responseString["result"] as? [AnyObject] // posts started with array
                    {
                        for post in resultado
                        {
                            let objetoInfo = post["info"] as! NSDictionary
                            let objetoProgramas = post["programas"] as! NSDictionary
                            
                            let titulo = objetoInfo["title"] as! String
                            let slug = objetoInfo["slug"] as! String
                            let dataexib = objetoInfo["date"] as! String
                            
                            let descricao = objetoProgramas["description"] as! String
                            let logoPrograma = objetoProgramas["logoAppPath"] as! String
                            let exibicao = objetoProgramas["exhibitionTime"] as! String
                            
                            let novoPrograma:Programa = Programa(nome: titulo, descricao: descricao,slug:slug, youtubeID:logoPrograma, data:dataexib, exibicao:exibicao)
                            
                            self.listaAcervo.append(novoPrograma)
                        }
                        DispatchQueue.main.sync
                            {
                                self.inicializaMenuAcervos(numeroDeProgramas, numeroDeColunas: 2)
                        }
                    }
                    else{ print("I could not find post array")}
                }
                else{ print("No data got from url!")}
            }
            else{ print("error httpstatus code is :",httpStatus!.statusCode)}
        }
        task.resume()
    }
    
    
    
    
    
    
    
    
    
    func clicaLogoPrograma(_ gestureRecognizer: UITapGestureRecognizer) {
        let imagemTocada = gestureRecognizer.view!
        
        if ((imagemTocada.tag>=0)&&(imagemTocada.tag<listaProgramas.count)){
            print("ICONE PROGRAMA - TAG: \(imagemTocada.tag)")
            tagClicada = imagemTocada.tag
            selecionouAcervo = false
            self.performSegue(withIdentifier: "HomeParaEpisodios", sender: nil)
            
        }else if ((imagemTocada.tag>=900)&&(imagemTocada.tag<(900+listaAcervo.count))){
            print("ICONE ACERVO - TAG: \(imagemTocada.tag)")
            tagClicada = imagemTocada.tag - 900
            selecionouAcervo = true
            self.performSegue(withIdentifier: "HomeParaEpisodios", sender: nil)
            
        }else if ((imagemTocada.tag>=300)&&(imagemTocada.tag<(300+listaDestaques.count))){
            print("ICONE DESTAQUE - TAG: \(imagemTocada.tag)")
            tagClicada = imagemTocada.tag - 300
            self.performSegue(withIdentifier: "SegueHomeToVideo", sender: nil)
            
        }else if (imagemTocada.tag == 500){
            print("ICONE RADIO CULTURA FM - TAG: \(imagemTocada.tag)")
            radioSelecionada = "CulturaFM"
            self.performSegue(withIdentifier: "SegueRadios", sender: nil)
            
        }else if(imagemTocada.tag == 501){
            print("ICONE RADIO BRASIL - TAG: \(imagemTocada.tag)")
            radioSelecionada = "CulturaBrasil"
            self.performSegue(withIdentifier: "SegueRadios", sender: nil)
        }
    }
    
    
    
    func clicaMaisProgramas(_ sender: UIButton!) {
        if (sender.tag == 1){
            print("MAIS PROGRAMA - TAG: \(sender.tag)")
            self.performSegue(withIdentifier: "ListaProgramas", sender: nil)
        }else if (sender.tag == 2){
            print("MAIS ACERVO - TAG: \(sender.tag)")
            self.performSegue(withIdentifier: "ListaProgramas", sender: nil)
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier! == "SegueHomeToVideo"){
            let proximaTela:Video = segue.destination as! Video
            proximaTela.meuEpisodio.titulo = listaDestaques[tagClicada].titulo
            proximaTela.meuEpisodio.descricao = listaDestaques[tagClicada].descricao
            proximaTela.meuEpisodio.youtubeID = listaDestaques[tagClicada].youtubeID
            proximaTela.meuEpisodio.dataEpisodio = listaDestaques[tagClicada].dataDestaque
        }
        
        if((segue.identifier! == "HomeParaEpisodios")&&(!selecionouAcervo)&&(!clicouBusca)){
            let proximaTela:ListaEpisodios = segue.destination as! ListaEpisodios
            proximaTela.nomePrograma = listaProgramas[tagClicada].slug
        }
        
        if((segue.identifier! == "HomeParaEpisodios")&&(selecionouAcervo)){
            let proximaTela:ListaEpisodios = segue.destination as! ListaEpisodios
            proximaTela.nomePrograma = listaAcervo[tagClicada].slug
        }
        
        if(clicouBusca){
            let proximaTela:ListaEpisodios = segue.destination as! ListaEpisodios
            proximaTela.nomePrograma = "Busca por Programa"
        }
        
        
    }
    
    
}
