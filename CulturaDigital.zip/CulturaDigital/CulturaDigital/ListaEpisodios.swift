//
//  ListaEpisodios.swift
//  Lista de Programas
//
//  Created by Tito Petri on 04/08/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import UIKit

class ListaEpisodios: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    var nomePrograma:String = ""
    
    var minhaListaVideos:UITableView = UITableView()
    var minhaListaDeEpisodios:[Episodio] = []
    lazy var minhaSearchBar:UISearchBar = UISearchBar(frame: CGRect(x: 0, y: 0, width: 200, height: 20))
    
    var buscaUsuario:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black
        minhaSearchBar.placeholder = "Busca"
        let leftNavBarButton = UIBarButtonItem(customView:minhaSearchBar)
        self.navigationItem.rightBarButtonItem = leftNavBarButton
        
        if nomePrograma == "Busca por Programa" {
            minhaSearchBar.becomeFirstResponder()
        }else{
            buscaAPIVideos(nomePrograma)
        }
        
        minhaSearchBar.delegate = self
        
        minhaListaVideos = UITableView(frame: CGRect(x: 0, y: 0, width: larguraTela, height: alturaTela ))
        minhaListaVideos.backgroundColor = UIColor.black
        
        minhaListaVideos.delegate = self
        minhaListaVideos.dataSource = self
        self.view.addSubview(minhaListaVideos)
        
        minhaListaVideos.register(CelulaListaEpisodios.self, forCellReuseIdentifier: "Minha Celula")
        minhaListaVideos.reloadData()
        
//        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ListaEpisodios.dismissKeyboard))
//        view.addGestureRecognizer(tap)
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let minhaCelula = minhaListaVideos.dequeueReusableCell(withIdentifier: "Minha Celula", for: indexPath) as! CelulaListaEpisodios
        let episodio = minhaListaDeEpisodios[(indexPath as NSIndexPath).row] as Episodio
        minhaCelula.textoTitulo.text = episodio.titulo
        minhaCelula.textoDescricao.text = episodio.descricao
        minhaCelula.youTubeId = episodio.youtubeID
        minhaCelula.dataPrograma.text = episodio.dataEpisodio
        return minhaCelula
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return alturaImagensYouTube + 150 + margemPadrao
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return minhaListaDeEpisodios.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        minhaListaVideos.deselectRow(at: indexPath, animated: true)
        self.performSegue(withIdentifier: "Segue Video", sender: (indexPath as NSIndexPath).row)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let programaSelecionado:Int = sender as! Int
        let proximaTela:Video = segue.destination as! Video
        proximaTela.meuEpisodio = minhaListaDeEpisodios[programaSelecionado]
    }
    
    
    
    
    /*
     
     func buscaAPIVideosOLD(_ busca:String){
     let opcaoVideos = "recentes"
     let nomeBusca = busca.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)
     var apiUrl = "http://tvcultura.com.br/json/videos/?programa=\(nomeBusca!)&order=\(opcaoVideos)"
     
     if !buscaUsuario{
     apiUrl = "http://tvcultura.com.br/json/videos/?programa=\(nomeBusca!)&order=\(opcaoVideos)"
     }else{
     apiUrl = "http://tvcultura.com.br/json/busca/?q=\(nomeBusca!)&order=\(opcaoVideos)"
     }
     
     let url = URL(string: apiUrl)
     let session = URLSession.shared
     
     let task = session.dataTask(with: url!, completionHandler: {data, response, error -> Void in
     if (error != nil){
     print(error!.localizedDescription)
     }else{
     
     let nsdata:Data = NSData(data: data!) as Data
     
     do{
     self.minhaListaDeEpisodios.removeAll()
     self.minhaListaVideos.reloadData()
     
     let jsonCompleto = try JSONSerialization.jsonObject(with: nsdata, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String:Any]
     if let arrayComJason = jsonCompleto["result"] as? NSArray{
     arrayComJason.enumerateObjects({ (objeto, index, stop) in
     
     let objetoVideos = objeto["videos"] as! NSDictionary
     let objetoInfo = objeto["info"] as! NSDictionary
     let novoEpisodio:Episodio = Episodio(titulo: (objetoInfo["title"]! as! String), descricao: (objetoVideos["content"]! as! String), youtubeID:(objetoVideos["YTID"]! as! String), dataEpisodio:(objetoInfo["date"]! as! String))
     self.minhaListaDeEpisodios.append(novoEpisodio)
     })
     DispatchQueue.main.async(execute: {
     self.minhaListaVideos.reloadData() } )
     }
     }
     catch {}
     }
     })
     task.resume()
     }
     
     
     
     
     
     */
    
    
    
    
    
    func buscaAPIVideos(_ busca:String){
        
        
        let opcaoVideos = "recentes"
        let nomeBusca = busca.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)
        var apiUrl = "http://tvcultura.com.br/json/videos/?programa=\(nomeBusca!)&order=\(opcaoVideos)"
        
        if !buscaUsuario{
            apiUrl = "http://tvcultura.com.br/json/videos/?programa=\(nomeBusca!)&order=\(opcaoVideos)"
        }else{
            apiUrl = "http://tvcultura.com.br/json/busca/?q=\(nomeBusca!)&order=\(opcaoVideos)"
        }
        let url = URL(string: apiUrl)
        let request = NSMutableURLRequest(url: url! as URL)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data,response,error in
            guard error == nil && data != nil else
            {
                print("Error:",error)
                return
            }
            
            let httpStatus = response as? HTTPURLResponse
            
            if httpStatus!.statusCode == 200
            {
                if data?.count != 0
                {
                    let responseString = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! NSDictionary
                    
//                    let temProximo = responseString["hasNext"] as! Bool
//                    let proximoInicio = responseString["nextStart"] as! Int
//                    let total = responseString["total"] as! Int
//                    let listaProgramas = responseString["result"] as! NSArray
                    
                    
                    if let resultado = responseString["result"] as? [AnyObject] // posts started with array
                    {
                        for post in resultado
                        {
                            let objetoInfo = post["info"] as! NSDictionary
                            let objetoVideos = post["videos"] as! NSDictionary
                            
                            let novoEpisodio:Episodio = Episodio(titulo: (objetoInfo["title"]! as! String), descricao: (objetoVideos["content"]! as! String), youtubeID:(objetoVideos["YTID"]! as! String), dataEpisodio:(objetoInfo["date"]! as! String))
                            
                            self.minhaListaDeEpisodios.append(novoEpisodio)
                            
                            DispatchQueue.main.sync
                                {
                                    self.minhaListaVideos.reloadData()
                            }
                        }
                    }
                    else{ print("I could not find post array")}
                }
                else{ print("No data got from url!")}
            }
            else{ print("error httpstatus code is :",httpStatus!.statusCode)}
        }
        task.resume()
    }
    
    

    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        buscaUsuario = true
        buscaAPIVideos(searchBar.text!)
        searchBar.text = ""
    }
    
    func dismissKeyboard() {
        view.endEditing(false)
    }
    
}

