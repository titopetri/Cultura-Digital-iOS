//
//  ViewController.swift
//  TVCulturaBuscaProgramas
//
//  Created by Tito Petri on 09/09/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import UIKit

class ListaProgramas: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var proximoInicioBusca:Int = 0
    var maisResultados:Bool = false
    var podeCarregarMaisDados:Bool = false
    
    var listaDeProgramas:[Programa] = []
    
    
    var minhaLista:UITableView = UITableView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buscaPorProgramas(0)
        minhaLista = UITableView(frame: CGRect(x: 0, y: 0, width: larguraTela, height: alturaTela))
        minhaLista.delegate = self
        minhaLista.dataSource = self
        minhaLista.backgroundColor = UIColor.black
        minhaLista.scrollsToTop = false
        minhaLista.register(CelulaListaProgramas.self, forCellReuseIdentifier: "Celula Programas")
        self.view.addSubview(minhaLista)
        
        let textoTituloNavBar = UILabel()
        textoTituloNavBar.text = "Programas"
        textoTituloNavBar.textColor = corVerde
        textoTituloNavBar.textAlignment = .center
        textoTituloNavBar.font = UIFont(name: "Roboto-Bold", size: 21)
        textoTituloNavBar.frame = CGRect(x: 0, y: 0, width: larguraTela, height: alturaNavbar)
        self.navigationItem.titleView = textoTituloNavBar
        
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(ListaProgramas.titleWasTapped))
        textoTituloNavBar.isUserInteractionEnabled = true
        textoTituloNavBar.addGestureRecognizer(recognizer)
    }
    
    func titleWasTapped() {
        minhaLista.setContentOffset(CGPoint(x: 0,y: -(alturaNavbar+alturaStatusBar)) , animated: true)
    }
    
    
    
    /*
     func buscaPorProgramasOLD(_ inicio:Int){
     
     let apiUrl = "http://tvcultura.com.br/json/programas/?app=true"
     
     let url = URL(string: apiUrl)
     let session = URLSession.shared
     
     let task = session.dataTask(with: url!, completionHandler: {data, response, error -> Void in
     if (error != nil){
     print(error!.localizedDescription)
     }else{
     let nsdata:Data = NSData(data: data!) as Data
     do{
     
     
     let jsonCompleto = try JSONSerialization.jsonObject(with: nsdata, options: JSONSerialization.ReadingOptions.mutableContainers) as! [String:Any]
     
     //                    let numeroDeResultados = jsonCompleto["total"] as! Int
     let maisResultados = jsonCompleto["hasNext"] as! Bool
     let inicioProximoResultado = jsonCompleto["nextStart"] as! Int
     
     self.proximoInicioBusca = inicioProximoResultado
     self.maisResultados = maisResultados
     
     if let arrayComJason = jsonCompleto["result"] as? NSArray{
     
     arrayComJason.enumerateObjects({ (objeto, index, stop) in
     
     let objetoInfo = objeto["info"] as! NSDictionary
     let objetoProgramas = objeto["programas"] as! NSDictionary
     
     let novoPrograma:Programa = Programa(nome: (objetoInfo["title"]! as! String), descricao: (objetoProgramas["description"]! as! String),slug:(objetoInfo["slug"])! as! String, youtubeID:(objetoProgramas["logoAppPath"]! as! String), data:(objetoInfo["date"]! as! String), exibicao:(objetoProgramas["exhibitionTime"]! as! String))
     
     self.listaDeProgramas.append(novoPrograma)
     print(novoPrograma)
     })
     DispatchQueue.main.async(execute: {
     self.podeCarregarMaisDados=true;
     self.minhaLista.reloadData()
     } )
     }
     }
     catch {}
     }
     })
     task.resume()
     }
     
     */
    
    
    
    
    
    func buscaPorProgramas(_ inicio:Int){
        
        
        let url = NSURL(string: "http://tvcultura.com.br/json/programas/?app=true")
        let request = NSMutableURLRequest(url: url! as URL)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data,response,error in
            guard error == nil && data != nil else
            {
                print("Error:",error)
                return
            }
            
            let httpStatus = response as? HTTPURLResponse
            
            if httpStatus!.statusCode == 200
            {
                if data?.count != 0
                {
                    let responseString = try! JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! NSDictionary
                    
                    let temProximo = responseString["hasNext"] as! Bool
                    let proximoInicio = responseString["nextStart"] as! Int
//                    let total = responseString["total"] as! Int
//                    let listaProgramas = responseString["result"] as! NSArray
                    
                    self.proximoInicioBusca = proximoInicio
                    self.maisResultados = temProximo
                    
                    if let resultado = responseString["result"] as? [AnyObject] // posts started with array
                    {
                        for post in resultado
                        {
                            let objetoInfo = post["info"] as! NSDictionary
                            let objetoProgramas = post["programas"] as! NSDictionary
                            
                            let novoPrograma:Programa = Programa(nome: (objetoInfo["title"]! as! String), descricao: (objetoProgramas["description"]! as! String),slug:(objetoInfo["slug"])! as! String, youtubeID:(objetoProgramas["logoAppPath"]! as! String), data:(objetoInfo["date"]! as! String), exibicao:(objetoProgramas["exhibitionTime"]! as! String))
                            
                            self.listaDeProgramas.append(novoPrograma)
                            
                            DispatchQueue.main.sync
                                {
                                    self.podeCarregarMaisDados=true;
                                    self.minhaLista.reloadData()
                            }
                        }
                    }
                    else{ print("I could not find post array")}
                }
                else{ print("No data got from url!")}
            }
            else{ print("error httpstatus code is :",httpStatus!.statusCode)}
        }
        task.resume()
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let minhaCelula = minhaLista.dequeueReusableCell(withIdentifier: "Celula Programas", for: indexPath) as! CelulaListaProgramas
        
        let programa = listaDeProgramas[(indexPath as NSIndexPath).row] as Programa
        minhaCelula.textoTitulo.text = programa.nome
        minhaCelula.textoDescricao.text = programa.descricao
        minhaCelula.textoHorarioDeExibicao.text = programa.exibicao
        minhaCelula.youTubeId = programa.youtubeID
        minhaCelula.backgroundView?.backgroundColor = corVerde
        return minhaCelula
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaDeProgramas.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return alturaImagensProgramas + 110 + margemPadrao
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        minhaLista.deselectRow(at: indexPath, animated: true)
        self.performSegue(withIdentifier: "Lista Episodios", sender: (indexPath as NSIndexPath).row)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let programaSelecionado:Int = sender as! Int
        let proximaTela:ListaEpisodios = segue.destination as! ListaEpisodios
        proximaTela.nomePrograma = listaDeProgramas[programaSelecionado].slug
    }
    
}

