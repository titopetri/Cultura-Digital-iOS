//
//  Programa.swift
//  Lista de Programas
//
//  Created by Tito Petri on 04/08/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import Foundation

class Programa {
    
    var nome:String
    var descricao:String
    var slug:String
    var youtubeID:String
    var data:String
    var exibicao:String
    
    init(nome:String, descricao:String, slug:String, youtubeID:String, data:String, exibicao:String){
        self.nome = nome
        self.descricao = descricao
        self.slug = slug
        self.youtubeID = youtubeID
        self.data = data
        self.exibicao = exibicao
    }
    
}