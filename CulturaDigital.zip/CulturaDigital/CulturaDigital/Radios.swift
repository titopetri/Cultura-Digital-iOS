//
//  Radios.swift
//  CulturaDigital
//
//  Created by Tito Petri on 12/09/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//

import UIKit
import AVFoundation
import MediaPlayer

class Radios: UIViewController {
    
    
    var meuWebView:UIWebView = UIWebView()
    var meuTitulo:UILabel = UILabel()
    var minhaDescricao:UITextView = UITextView()
    var switchRadioFM:UISwitch = UISwitch()
    var switchRadioBrasil:UISwitch = UISwitch()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black
        
        let textoTituloNavBar = UILabel()
        textoTituloNavBar.text = "Rádios"
        textoTituloNavBar.textColor = corVerde
        textoTituloNavBar.textAlignment = .center
        textoTituloNavBar.font = UIFont(name: "Roboto-Bold", size: 21)
        textoTituloNavBar.frame = CGRect(x: 0, y: 0, width: larguraTela, height: alturaNavbar)
        self.navigationItem.titleView = textoTituloNavBar
        
        let imagemCulturaFM:UIImageView = UIImageView(frame: CGRect(x: margemPadrao/2, y: margemPadrao/2 + alturaNavbar + alturaStatusBar + 10, width: larguraTela - margemPadrao, height: (larguraTela - margemPadrao)/1.85))
        let imagemCulturaBrasil:UIImageView = UIImageView(frame: CGRect(x: margemPadrao/2, y: margemPadrao/2 + imagemCulturaFM.frame.maxY + margemPadrao*3, width: larguraTela - margemPadrao, height: (larguraTela - margemPadrao)/1.85))
        
        imagemCulturaFM.image = UIImage(named:listaImagensRadio[0])
        imagemCulturaBrasil.image = UIImage(named:listaImagensRadio[1])
        
        imagemCulturaFM.isUserInteractionEnabled = true
        imagemCulturaBrasil.isUserInteractionEnabled = true
        
        switchRadioFM = UISwitch();
        switchRadioBrasil = UISwitch();
        
        switchRadioFM.addTarget(self, action: #selector(clicaRadioFM(_:)), for: UIControlEvents.valueChanged)
        switchRadioBrasil.addTarget(self, action: #selector(clicaRadioBrasil(_:)), for: UIControlEvents.valueChanged)
        
        
        switchRadioBrasil.frame.origin.x = imagemCulturaBrasil.frame.maxX - switchRadioBrasil.frame.width - margemPadrao
        switchRadioBrasil.frame.origin.y = imagemCulturaBrasil.frame.origin.y + margemPadrao
        
        switchRadioFM.frame.origin.x = imagemCulturaFM.frame.maxX - switchRadioFM.frame.width - margemPadrao
        switchRadioFM.frame.origin.y = imagemCulturaFM.frame.origin.y + margemPadrao
        
        
        self.view.addSubview(imagemCulturaFM)
        self.view.addSubview(imagemCulturaBrasil)
        self.view.addSubview(switchRadioFM);
        self.view.addSubview(switchRadioBrasil);
        
        switchRadioFM.onTintColor = corVerde
        switchRadioBrasil.onTintColor = corAzul
        
        
        self.navigationItem.hidesBackButton = true
        let newBackButton = UIBarButtonItem(title: "Voltar", style: UIBarButtonItemStyle.plain, target: self, action: #selector(Radios.clicaVoltar(_:)))
        self.navigationItem.leftBarButtonItem = newBackButton;
         
    }
    
    
    
    func clicaRadioFM(_ sender:UISwitch!){
        
       
        
        urlRadio = "http://midiaserver.tvcultura.com.br:8003"
        RadioPlayer.sharedInstance.resgistraNovo()
        
        if NSClassFromString("MPNowPlayingInfoCenter") != nil {
            let songInfo = [
                MPMediaItemPropertyTitle: "Radio Cultura FM",
                MPMediaItemPropertyArtist: "103.3 FM",
                ]
            MPNowPlayingInfoCenter.default().nowPlayingInfo = songInfo
        }
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            UIApplication.shared.beginReceivingRemoteControlEvents()
            print("Receiving remote control events\n")
        } catch {
            print("Audio Session error.\n")
        }
        
        
        
        toggle()
    }
    
    func clicaRadioBrasil(_ sender:UISwitch!){
        
        urlRadio = "http://midiaserver.tvcultura.com.br:8001"
        RadioPlayer.sharedInstance.resgistraNovo()
        if NSClassFromString("MPNowPlayingInfoCenter") != nil {
            let songInfo = [
                MPMediaItemPropertyTitle: "Radio Cultura Brasil",
                MPMediaItemPropertyArtist: "1200 AM",
                ]
            MPNowPlayingInfoCenter.default().nowPlayingInfo = songInfo
        }
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            UIApplication.shared.beginReceivingRemoteControlEvents()
            print("Receiving remote control events\n")
        } catch {
            print("Audio Session error.\n")
        }
        toggle()
    }
    
    func toggle() {
        if RadioPlayer.sharedInstance.currentlyPlaying() {
            pauseRadio()
        } else {
            playRadio()
        }
    }
    
    func playRadio() {
        RadioPlayer.sharedInstance.play()
        UIApplication.shared.isIdleTimerDisabled = true
        
    }
    
    func pauseRadio() {
        RadioPlayer.sharedInstance.pause()
        UIApplication.shared.isIdleTimerDisabled = false
    }
    
    func clicaVoltar(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
        pauseRadio()
        
    }
    
}
