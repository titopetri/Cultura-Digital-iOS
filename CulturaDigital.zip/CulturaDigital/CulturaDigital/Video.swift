//
//  TelaVideoPlayer.swift
//  Lista de Programas
//
//  Created by Tito Petri on 04/08/16.
//  Copyright © 2016 Tito Petri. All rights reserved.
//


import UIKit

class Video: UIViewController {
    
    var meuEpisodio:Episodio = Episodio(titulo: "", descricao: "", youtubeID: "", dataEpisodio: "")
    
    var meuWebView:UIWebView = UIWebView()
    var meuTitulo:UITextView = UITextView()
    var minhaData:UILabel = UILabel()
    var minhaDescricao:UITextView = UITextView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.backBarButtonItem?.title="Voltar"
        
        self.view.backgroundColor = UIColor.black
        
        meuWebView = UIWebView(frame: CGRect(x: margemPadrao/2, y: margemPadrao/2, width: larguraTela-margemPadrao, height: alturaTela/2))
        meuTitulo = UITextView(frame: CGRect(x: margemPadrao/2, y: meuWebView.frame.maxY , width: larguraTela-margemPadrao, height: 60))
        minhaData = UILabel(frame: CGRect(x: margemPadrao/2, y: meuTitulo.frame.maxY , width: larguraTela-margemPadrao, height: 20))
        minhaDescricao = UITextView(frame: CGRect(x: margemPadrao/2, y: minhaData.frame.maxY , width: larguraTela-margemPadrao, height:alturaTela/2 - meuTitulo.frame.height - minhaData.frame.height))
        meuTitulo.isScrollEnabled = false
        minhaDescricao.isScrollEnabled = true
        minhaDescricao.backgroundColor = corChumbo
        
        
        meuTitulo.textColor = UIColor.white
        meuTitulo.font = UIFont(name: "Roboto-Bold", size: 17)
        
        minhaDescricao.textColor = UIColor.white
        minhaDescricao.font = UIFont(name: "Roboto-Regular", size: 15)
        
        minhaData.textColor = corVerde
        minhaData.font = UIFont(name: "Roboto-Bold", size: 17)
        minhaData.textAlignment = .right
        
        meuTitulo.text = meuEpisodio.titulo
        minhaDescricao.text = meuEpisodio.descricao
        minhaData.text = meuEpisodio.dataEpisodio
        
        meuTitulo.backgroundColor = UIColor.black
        meuWebView.isOpaque = false
        meuWebView.backgroundColor = UIColor.clear
        
        
        let minhaUrlString = "https://www.youtube.com/embed/\(meuEpisodio.youtubeID)";
        let url = URL(string: minhaUrlString);
        let req = URLRequest(url: url!);
        meuWebView.loadRequest(req);
        
        let meuIndicador:UIActivityIndicatorView = UIActivityIndicatorView(frame: meuWebView.frame)
        meuIndicador.startAnimating()
        meuIndicador.hidesWhenStopped = true
        
        self.view.addSubview(meuIndicador)
        self.view.addSubview(meuWebView)
        self.view.addSubview(meuTitulo)
        self.view.addSubview(minhaData)
        self.view.addSubview(minhaDescricao)
        self.navigationController!.navigationBar.backItem?.title = "Voltar"
        
        
    }
    
}
